FAST SOLUTIONS — Language-selection QR website
================================================

Included:
- index.html: bilingual language-selection page
- company-profile-ar.pdf: Arabic company profile
- company-profile-en.pdf: English company profile

IMPORTANT:
The QR code must point to a public website URL. It cannot reliably open files directly from this ZIP or from your phone.
After publishing this folder, send me the public website URL and I can generate the final QR code for you.

Quick free publishing option (Netlify Drop):
1. Extract this ZIP on your computer.
2. Open https://app.netlify.com/drop in your browser.
3. Drag the extracted folder "fast_solutions_language_qr_site" onto the page (or drag its contents if requested).
4. Netlify will give you a public URL ending in netlify.app.
5. Send me that URL. I will make the final QR code that opens the language chooser.

Before printing the QR, test the public URL on a phone and check both language buttons.
